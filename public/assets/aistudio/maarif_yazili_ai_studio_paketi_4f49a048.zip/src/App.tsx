import React, { useState } from 'react';
import { parseUniversalFile, UniversalFilePayload } from './utils/universalFileParser';
import { gradeExamWithGemini, GradingResult } from './services/geminiGrader';
import * as XLSX from 'xlsx';

export default function App() {
  const [rubricFile, setRubricFile] = useState<UniversalFilePayload | null>(null);
  const [paperFile, setPaperFile] = useState<UniversalFilePayload | null>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<GradingResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleRubricUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files?.[0]) return;
    const parsed = await parseUniversalFile(e.target.files[0]);
    setRubricFile(parsed);
  };

  const handlePaperUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files?.[0]) return;
    const parsed = await parseUniversalFile(e.target.files[0]);
    setPaperFile(parsed);
  };

  const handleRunGrading = async () => {
    if (!rubricFile || !paperFile) {
      setError('Lütfen hem rubrik dosyasını hem de öğrenci kağıdını yükleyin.');
      return;
    }
    setError(null);
    setLoading(true);
    try {
      const graded = await gradeExamWithGemini(rubricFile, paperFile);
      setResult(graded);
    } catch (err: any) {
      setError(err?.message || 'Puanlama sırasında hata oluştu.');
    } finally {
      setLoading(false);
    }
  };

  const exportToExcel = () => {
    if (!result) return;
    const rows = result.questions.map(q => ({
      'Soru No': q.questionNo,
      'Maarif Çıktısı': q.learningOutcome,
      'Tam Puan': q.maxScore,
      'Alınan Puan': q.awardedScore,
      'Okunan Cevap (OCR)': q.transcribedAnswer,
      'Öğretmen Gerekçesi': q.teacherFeedback
    }));
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Değerlendirme');
    XLSX.writeFile(wb, `${result.studentName || 'Ogrenci'}_Analiz.xlsx`);
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 p-6 font-sans">
      <div className="max-w-5xl mx-auto space-y-6">
        <header className="bg-white p-5 rounded-xl border border-slate-200 flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold text-slate-900">MaarifYazılı AI — Açık Uçlu Sınav Değerlendirme</h1>
            <p className="text-xs text-slate-500">Desteklenen Formatlar: PDF, Excel (.xlsx/.csv), Word (.docx), TXT, JPG, PNG</p>
          </div>
          {result && (
            <button onClick={exportToExcel} className="px-4 py-2 rounded-lg bg-emerald-600 text-white text-xs font-bold">
              Excel Raporu İndir (.xlsx)
            </button>
          )}
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <label className="bg-white p-5 rounded-xl border-2 border-dashed border-slate-300 hover:border-indigo-500 cursor-pointer block">
            <div className="text-xs font-bold uppercase text-indigo-600 mb-1">1. Adım: Sınav Rubriği Yükle</div>
            <div className="text-sm font-semibold">{rubricFile ? rubricFile.fileName : 'PDF, Excel, Word, TXT veya Görsel Seçin'}</div>
            <input type="file" accept=".pdf,.xlsx,.xls,.csv,.docx,.txt,image/*" onChange={handleRubricUpload} className="hidden" />
          </label>

          <label className="bg-white p-5 rounded-xl border-2 border-dashed border-slate-300 hover:border-indigo-500 cursor-pointer block">
            <div className="text-xs font-bold uppercase text-indigo-600 mb-1">2. Adım: Öğrenci Kağıdı Yükle</div>
            <div className="text-sm font-semibold">{paperFile ? paperFile.fileName : 'Taranmış PDF, JPG/PNG, Word veya TXT Seçin'}</div>
            <input type="file" accept=".pdf,.xlsx,.xls,.csv,.docx,.txt,image/*" onChange={handlePaperUpload} className="hidden" />
          </label>
        </div>

        <button
          onClick={handleRunGrading}
          disabled={loading}
          className="w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-400 text-white font-bold text-sm transition"
        >
          {loading ? 'Maarif Muhakeme Motoru Kağıdı Okuyor ve Puanlıyor...' : '⚡ Rubriğe Göre Puanla ve Analiz Raporu Oluştur'}
        </button>

        {error && <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">{error}</div>}

        {result && (
          <div className="bg-white p-6 rounded-xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between border-b pb-3">
              <div>
                <h2 className="text-lg font-extrabold">{result.studentName} ({result.className} - No: {result.studentNumber})</h2>
                <p className="text-xs text-slate-500">{result.overallStrengths}</p>
              </div>
              <div className="text-2xl font-black text-indigo-700">{result.totalScore} / 100</div>
            </div>

            <div className="space-y-3">
              {result.questions.map((q) => (
                <div key={q.questionNo} className="p-4 rounded-lg bg-slate-50 border border-slate-200 space-y-1.5">
                  <div className="flex justify-between text-xs font-bold">
                    <span>Soru {q.questionNo} ({q.learningOutcome})</span>
                    <span className="text-indigo-700">{q.awardedScore} / {q.maxScore} Puan</span>
                  </div>
                  <div className="text-xs text-slate-700 bg-white p-2.5 rounded border">
                    <strong>Öğrenci Cevabı (OCR):</strong> {q.transcribedAnswer}
                  </div>
                  <div className="text-xs text-indigo-900">
                    <strong>Değerlendirme Gerekçesi:</strong> {q.teacherFeedback}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
