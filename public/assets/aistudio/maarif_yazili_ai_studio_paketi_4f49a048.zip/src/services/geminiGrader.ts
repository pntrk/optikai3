import { GoogleGenAI, Type } from "@google/genai";
import { UniversalFilePayload } from "../utils/universalFileParser";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export interface QuestionEvaluation {
  questionNo: number;
  learningOutcome: string;
  maxScore: number;
  awardedScore: number;
  transcribedAnswer: string;
  matchedCriteria: string[];
  missingCriteria: string[];
  teacherFeedback: string;
}

export interface GradingResult {
  studentName: string;
  studentNumber: string;
  className: string;
  totalScore: number;
  questions: QuestionEvaluation[];
  overallStrengths: string;
  overallImprovements: string;
}

function toGeminiPart(file: UniversalFilePayload, label: string) {
  if (file.mode === "inlineData" && file.base64Data && file.mimeType) {
    return [
      { text: `[${label} Dosyası: ${file.fileName}]` },
      { inlineData: { mimeType: file.mimeType, data: file.base64Data } }
    ];
  }
  return [
    { text: `[${label} Metin İçeriği (${file.fileName})]:\n${file.extractedText}` }
  ];
}

export async function gradeExamWithGemini(
  rubric: UniversalFilePayload,
  studentPaper: UniversalFilePayload
): Promise<GradingResult> {
  const contents = [
    ...toGeminiPart(rubric, "SINAV RUBRİĞİ"),
    ...toGeminiPart(studentPaper, "ÖĞRENCİ CEVAP KAĞIDI"),
    {
      text: `Sen Türkiye Yüzyılı Maarif Modeli ölçme ve değerlendirme uzmanısın.
1. Rubrikteki her sorunun öğrenme çıktısını, tam puanını ve kabul kriterlerini esas al.
2. Öğrenci kağıdındaki el yazısını veya metni eksiksiz oku (OCR).
3. Öğrencinin cevabını rubrikle karşılaştır, yakalanan ve eksik kalan unsurları belirle, kısmi puanları adil şekilde hesapla.`
    }
  ];

  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          studentName: { type: Type.STRING },
          studentNumber: { type: Type.STRING },
          className: { type: Type.STRING },
          totalScore: { type: Type.NUMBER },
          questions: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                questionNo: { type: Type.NUMBER },
                learningOutcome: { type: Type.STRING },
                maxScore: { type: Type.NUMBER },
                awardedScore: { type: Type.NUMBER },
                transcribedAnswer: { type: Type.STRING },
                matchedCriteria: { type: Type.ARRAY, items: { type: Type.STRING } },
                missingCriteria: { type: Type.ARRAY, items: { type: Type.STRING } },
                teacherFeedback: { type: Type.STRING }
              },
              required: ["questionNo", "maxScore", "awardedScore", "transcribedAnswer", "teacherFeedback"]
            }
          },
          overallStrengths: { type: Type.STRING },
          overallImprovements: { type: Type.STRING }
        },
        required: ["studentName", "totalScore", "questions", "overallStrengths", "overallImprovements"]
      }
    }
  });

  return JSON.parse(response.text || "{}") as GradingResult;
}
