import * as XLSX from "xlsx";
import mammoth from "mammoth";

export interface UniversalFilePayload {
  fileName: string;
  mode: "inlineData" | "text";
  mimeType?: string;
  base64Data?: string;
  extractedText?: string;
}

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const res = String(reader.result || "");
      resolve(res.includes(",") ? res.split(",")[1] : res);
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export async function parseUniversalFile(file: File): Promise<UniversalFilePayload> {
  const ext = file.name.split(".").pop()?.toLowerCase() || "";

  // 1. PDF ve Görseller (JPG, PNG, WEBP) -> Gemini Multimodal inlineData
  if (ext === "pdf" || file.type.startsWith("image/")) {
    const base64Data = await fileToBase64(file);
    const mimeType = ext === "pdf" ? "application/pdf" : file.type || "image/jpeg";
    return { fileName: file.name, mode: "inlineData", mimeType, base64Data };
  }

  // 2. Excel (.xlsx, .xls, .csv) -> SheetJS ile metin/JSON'a dönüştür
  if (["xlsx", "xls", "csv"].includes(ext)) {
    const buffer = await file.arrayBuffer();
    const workbook = XLSX.read(buffer, { type: "array" });
    const lines: string[] = [];
    workbook.SheetNames.forEach((sheetName) => {
      const sheet = workbook.Sheets[sheetName];
      const rows = XLSX.utils.sheet_to_json(sheet, { header: 1 }) as any[][];
      lines.push(`--- Sayfa: ${sheetName} ---`);
      rows.forEach((r) => {
        if (r && r.length) lines.push(r.join(" | "));
      });
    });
    return { fileName: file.name, mode: "text", extractedText: lines.join("\n") };
  }

  // 3. Word (.docx) -> Mammoth ile temiz metne dönüştür
  if (ext === "docx") {
    const buffer = await file.arrayBuffer();
    const result = await mammoth.extractRawText({ arrayBuffer: buffer });
    return { fileName: file.name, mode: "text", extractedText: result.value };
  }

  // 4. TXT, JSON, Markdown -> Doğrudan UTF-8 metin oku
  const text = await file.text();
  return { fileName: file.name, mode: "text", extractedText: text };
}
